import {NgModule} from '@angular/core';
import {TranslateModule} from 'ng2-translate/ng2-translate';

@NgModule({
    declarations: [],
    imports: [
        TranslateModule
    ],

    exports: [TranslateModule],
    providers: []

})
export class TranslaterModule {
}
