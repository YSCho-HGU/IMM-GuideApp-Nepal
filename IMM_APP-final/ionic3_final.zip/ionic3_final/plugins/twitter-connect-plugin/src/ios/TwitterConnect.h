
#ifndef HelloWorld_TwitterConnect_h
#define HelloWorld_TwitterConnect_h

#import <Cordova/CDV.h>


@interface TwitterConnect : CDVPlugin
@end
#endif